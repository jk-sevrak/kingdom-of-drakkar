Quick start:
1) Make sure drakkar is running

2) click 'Create A Macro'
  2) a)Enter a macro name in the 'Macro name' text field

  2) b)Enter a macro command in the 'Command' text field

  2) c)Toggle if the macro should auto return *default on*

  2) d)Toggle if the macro should stay toggled *default off* used for attacks

  2) e)Toggle if the macro should switch bewtween 2 commands each time it is used
       ex: ice spear; fire spear. first macro use casts ice spear, second time it is used fire spear is casted

  2) f)Click the blue square to select an icon for your macro

  2) g)Select who the macro should be used on.
        'Selected character' the macro will be used on the character who is selected on the character tab
        'All characters' the macro will be used on every character currently in the game
        'All ments' the macro will be used on every ment character currently in the game
        'All healers' the macro will be used on every healer character currently in the game
	'character name' your current characters will appear here, if selected the macro will only be used on this specific character

  2) h)Click 'Add Macro' to add it to the list of available macros

3)Select your macro by clicking it in the 'Macros' selection box *will turn green*
4)Click the location you want the macro to appear using the mock macro bars at the bottom of the window
   The shorter macro bar is the 'vertical' bar, will appear vertically. first spot is the top
   The 3 longer macro bars are the horizontal bars and will appear the same
   NOTE: No macro bars will be visible even if there are no macros placed in them!!

5)The actual macro bars will automatically open up when macros are placed in the mock marco bars
6)Place them in your preffered location
7)???
8)Enjoy!

Right click a macro in the mock macro bar to remove it

Press escape to cancel out of the macro creation process

Use a semi-colon ; in order to separate macro commands ex: (*STR 29; *RTG)

Right click a character name in the character tab in order to set that client as a master client, 
after macros are sent to other characters, this charater should regain the window focus


Special feature for searching;
When creating a macro for search, use the command 'search' without the quotes in order for exMacro to fill in the gaps 
and search the exact amount of corpses on the hex


Special feature for macros that place items in your sack;
The macro icon will appear red if the character whose is effected by the macro has a full sack


Special feature for taking items;
Every item has a id value, you can use that value in order to pick the item up (Use Oversight to see those values!)
When creating a macro to take items from somewhere, 
use the command 'take 30819'
exMacro will then fill in the gaps place the item in a free hand after finding in either your sack/pouch/belt


Special feature for using items;
When creating a macro to take items from somewhere, 
use the command 'use 30819'
exMacro will then fill in the gaps and use the desired item, great for the snowglobe buff!


Special feature for selling
use the command 'sellall' to sell all items in your sack
use the command 'sell gems' to sell all gems in your sack
use the command 'sell 23' to sell all items in your sack from the first slot(0) to the 24th slot(23). 
Note the top left slot is #0, bottom right is #29


Special feature for dropping gems
use the command 'drop gems' or 'Drop Gems' to drop all gems in your sack
Note: full hands won't stop the command from working


Special feature for switching to specific macro bars
use the command 'macro switch NAME' to switch to the macro bar NAME
ex: 'macro switch nork'
Note: macro bar names are case sensitive


Special feature for switching to specific characters
use the command 'switch to' and make sure when creating the macro you set the macro for a
specific character that you want to switch too.

ex: 
command -> 'switch to' 
character selection -> Hawk____ROAR
auto return checked

will bring up Hawk's drakkar client


Special feature for party creation
use command 'Party NAME' to create and join a party named NAME
selected character when creating the macro is the target who will create the party
all other characters will then join the party



Special command to send a single enter press
use command ENTER
ex: command1;command2;ENTER
Note: must be all uppercase to allow the world enter to be potentially used in other macros



Cast on party toggle;
will use the entered macro command on each party member.
example: form energyshield as the command
exMacro will then cast energyshield on each party member



Special command to have certain or all classes attack a target in a specific 'slot'
use command ' ATTACK-X; ' replacing X with slot number (from 1 to 10)
then add the class letter (list below) in uppercase followed by a dash ' - ' followed by the command to use

example of a attack macro to attack the first slot;
ATTACK-1;H-form assault;M-form enmiss;B-attack
with this command, exMacro should have the Healer cast assault, the ment cast enmiss, the barb simply attack the target in slot 1

H for healers
M for ments
P for paladins
B for barbs
FM for fighterments
F for fighters 
T for thieves
MA for martial artists



Special command to share character movements
use command 'SHAREMOVE' as the macros command
Note: requires 'Auto return' and 'Keep toggled' and must be toggled on a macrobar
With this command, movements done on the 'selected character' will also be sent to any other client



