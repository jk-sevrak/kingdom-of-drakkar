Available to launch
Discord, Drakkar, Oversight, ExMacro, Other

Note: 'Other' can be used to start any other exe, however moving and resizing will not be available 

Note: Avoid moving your mouse while the program is starting up drakkar clients

Note: Make sure to set the correct exe paths inside 'Config.txt' prior to use

Usage - See 'Launch_Example.txt' for an example of how a setup 'Launch.txt' should appear
	enter your launcher enteries into 'Launch.txt'
	Refer to the info below for the order the data should appear in


 Discord
 Yes/No 	  // Move window to different virtual desktop
 Number 0 to X    // Which virtual desktop to send it to, 0 is the furthest left desktop
 Yes/No	    	  // Resize window
 Width x Height   // Size of the window in pixels. Width x Height
 Yes/No		  // Move window position
 X,Y		  // X position , Y position (in screen coordinates) top left is 0,0


 Drakkar
 Yes/No 	  // Move window to different virtual desktop
 Number 0 to X    // Which virtual desktop to send it to, 0 is the furthest left desktop
 Yes/No	    	  // Resize window
 Width x Height   // Size of the window in pixels. Width x Height
 Yes/No		  // Move window position
 X,Y		  // X position , Y position (in screen coordinates) top left is 0,0
 Account	  // Name of the account to launch *Password must already be set as remembered in lobby for the named account*
 Number	    	  // Character slot number 0 to 3
 Number	    	  // Chat channel
 Yes/No	    	  // Minimize lobby?


 Oversight
 Yes/No 	  // Move window to different virtual desktop
 Number 0 to X    // Which virtual desktop to send it to, 0 is the furthest left desktop
 Yes/No	    	  // Resize window
 Width x Height   // Size of the window in pixels. Width x Height
 Yes/No		  // Move window position
 X,Y		  // X position , Y position (in screen coordinates) top left is 0,0


 ExMacro
 Yes/No 	  // Move window to different virtual desktop
 Number 0 to X    // Which virtual desktop to send it to, 0 is the furthest left desktop
 Yes/No	    	  // Resize window
 Width x Height   // Size of the window in pixels. Width x Height
 Yes/No		  // Move window position
 X,Y		  // X position , Y position (in screen coordinates) top left is 0,0

 Other
 Path to the exe  // The path to the exe to launch, example: C:/Games/DrakkarZone/irD/irD.exe


