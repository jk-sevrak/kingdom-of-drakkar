Place CritFixIt.exe in your Drakkar folder then run it when no characters are logged into the game

ex: C:\Games\DrakkarZone\Drakkar

May require administrator privileges and/or started as administrator to function correctly

Will not work if placed INSIDE the crts folder, be aware

Back up your crts folder just in case something goes wrong!