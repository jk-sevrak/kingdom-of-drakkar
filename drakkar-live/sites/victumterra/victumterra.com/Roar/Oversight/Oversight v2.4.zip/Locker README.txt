
To add a lockers items to oversight;
Click the locker icon (in oversight)
Click your characters name  (in oversight)
Click which locker you want to update  (in oversight)
Click the 'update' button after bringing your character (In drakkar) to that
specific locker, the locker window does not need to be open, just make sure you are ON
the locker hex

that is all!